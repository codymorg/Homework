
template <typename T> void quicksort(T* a, unsigned begin, unsigned size, int threads)
{
  PrintArray(a, size);
  quicksort_iterative(a, begin, size - 1);
  PrintArray(a, size);
}
