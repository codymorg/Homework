#ifndef QUICKSORT
#define QUICKSORT
#pragma once
#include <assert.h>
#include <iostream>

template <typename T> void quicksort_rec(T* a, unsigned begin, unsigned end);
template <typename T> void quicksort_iterative(T* a, unsigned begin, unsigned end);
template <typename T> void quicksort(T* a, unsigned, unsigned, int);

#ifdef _DEBUG
#include <mutex>
std::mutex printlock;
#endif

template <typename T> void PrintArray(T* a, int size, bool entire = false)
{
#ifdef _DEBUG
  printlock.lock();
  for (int i = 0; i < std::min(size, entire ? size : 25); i++)
  {
    std::cout << a[i];
    if (i < (entire ? size : 25))
      printf(", ");
  }
  if (size > (entire ? size : 25))
    printf("...");
  printf("\n");
  printlock.unlock();
#endif
}
void PrintLab(const char* label, int indent = 0, bool nl = true)
{
#ifdef _DEBUG
  printlock.lock();
  for (int i = 0; i < std::min(25, indent); i++)
  {
    printf("   ");
  }
  printf("%s", label);
  if (nl)
    printf("\n");
  printlock.unlock();
#endif
}

#include "sort_small_arrays.h"
#include <iostream>

template <typename T> unsigned partition(T* a, unsigned begin, unsigned end)
{
  unsigned i = begin, last = end - 1;
  T        pivot = a[last];

  for (unsigned j = begin; j < last; ++j)
  {
    if (a[j] < pivot)
    {
      PrintArray(a, end + 1);
      PrintLab("A", i, false);
      PrintLab("B", j - i);
      std::swap(a[j], a[i]);
      ++i;
    }
  }
  std::swap(a[i], a[last]);
  return i;
}

template <typename T> unsigned partition_new(T* a, unsigned begin, unsigned end)
{
  if (end - begin > 8)
    return partition_old(a, begin, end);

  unsigned i = begin, last = end - 1, step = (end - begin) / 4;

  T* pivots[5] = {a + begin, a + begin + step, a + begin + 2 * step, a + begin + 3 * step, a + last};
  quicksort_base_5_pointers(pivots);

  std::swap(a[last], a[begin + 2 * step]);
  T pivot = a[last];

  for (unsigned j = begin; j < last; ++j)
  {
    if (a[j] < pivot /*|| a[j]==pivot*/)
    {
      std::swap(a[j], a[i]);
      ++i;
    }
  }
  std::swap(a[i], a[last]);
  return i;
}

/* recursive */
template <typename T> void quicksort_rec(T* a, unsigned begin, unsigned end)
{
  if (end - begin < 6)
  {
    switch (end - begin)
    {
    case 5:
      quicksort_base_5(a + begin);
      break;
    case 4:
      quicksort_base_4(a + begin);
      break;
    case 3:
      quicksort_base_3(a + begin);
      break;
    case 2:
      quicksort_base_2(a + begin);
      break;
    }
    return;
  }

  unsigned q = partition(a, begin, end);

  quicksort_rec(a, begin, q);
  quicksort_rec(a, q, end);
}

/* iterative */
#define STACK
#define xVECTOR
#define xPRIORITY_QUEUE

#include <utility> // std::pair

template <typename T> using triple = typename std::pair<T*, std::pair<unsigned, unsigned>>;

template <typename T> struct compare_triples
{
  bool operator()(triple<T> const& op1, triple<T> const& op2) const
  {
    return op1.second.first > op2.second.first;
  }
};

#ifdef STACK
#include <stack>
template <typename T> using Container = std::stack<triple<T>>;
#define PUSH push
#define TOP top
#define POP pop
#endif

#ifdef VECTOR
#include <vector>
template <typename T> using Container = std::vector<triple<T>>;
#define PUSH push_back
#define TOP back
#define POP pop_back
#endif

#ifdef PRIORITY_QUEUE
#include <queue>
template <typename T> using Container = std::priority_queue<triple<T>, std::vector<triple<T>>, compare_triples<T>>;
#define PUSH push
#define TOP top
#define POP pop
#endif

template <typename T> void quicksort_iterative_aux(Container<T>& ranges);

template <typename T> void swapPivot(T* a, int begin, int pivotIndex)
{
  int i    = pivotIndex - 1;
  int size = pivotIndex;
  while (a[i] >= a[pivotIndex] && i >= begin)
  {
    PrintArray(a, size + 1);
    PrintLab("n", i, false);
    PrintLab("p", pivotIndex - i, true);
    std::swap(a[i], a[pivotIndex]);
    assert(a[i] < a[pivotIndex]);
    i--;
    pivotIndex--;
  }
  PrintArray(a, size + 1);
}


template <typename T> void quicksort_iterative(T* a, unsigned begin, unsigned end)
{
  Container<T> ranges;
  ranges.PUSH(std::make_pair(a, std::make_pair(begin, end)));
  quicksort_iterative_aux(ranges);
  swapPivot(a, begin, end);
}


template <typename T> void quicksort_iterative_aux(Container<T>& ranges)
{
  while (!ranges.empty())
  {
    triple<T> r = ranges.TOP();
    ranges.POP();

    T*       a = r.first;
    unsigned b = r.second.first;
    unsigned e = r.second.second;
    PrintArray(a, e + 1);
    PrintLab("[", b, false);
    PrintLab("]", e - b);

    // base case
    if (e - b < 6)
    {
      switch (e - b)
      {
      case 5:
        quicksort_base_5(a + b);
        break;
      case 4:
        quicksort_base_4(a + b);
        break;
      case 3:
        quicksort_base_3(a + b);
        break;
      case 2:
        quicksort_base_2(a + b);
        break;
      }
      continue;
    }
    unsigned q = partition(a, b, e);

    ranges.PUSH(std::make_pair(a, std::make_pair(b, q)));
    ranges.PUSH(std::make_pair(a, std::make_pair(q + 1, e)));
  }
}

#include "quicksort.cpp"
#endif
